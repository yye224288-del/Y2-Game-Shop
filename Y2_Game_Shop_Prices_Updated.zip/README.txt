Y2 Game Shop — Website
Updated Diamond prices:
86 = 5,600 Ks
172 = 11,000 Ks
257 = 16,500 Ks
343 = 21,200 Ks
429 = 27,000 Ks
515 = 31,800 Ks
706 = 42,000 Ks
878 = 53,000 Ks
963 = 58,000 Ks

Upload index.html and y2_logo.png to your GitHub repository.
Real payment verification and official MLBB top-up API are not connected in this demo.
